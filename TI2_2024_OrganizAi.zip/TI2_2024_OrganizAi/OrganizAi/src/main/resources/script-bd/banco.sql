-- Tabela de Tarefas
CREATE TABLE Tarefa (
    Tarefa_id SERIAL PRIMARY KEY,
    Nome VARCHAR(100) NOT NULL,
    Cor VARCHAR(50),
    Descricao VARCHAR(400),
    Duracao TIME,
    HorarioInicio TIME NOT NULL,
    HorarioFim TIME NOT NULL,
    PontosConclusao INT
);

-- Tabela de Níveis
CREATE TABLE Nivel (
    Nivel_id INT PRIMARY KEY,
    Regra INT NOT NULL,
    Recompensa VARCHAR(100)
);

-- Tabela de Estilos de Customização
CREATE TABLE EstiloCustomizacao (
    Estilos_id SERIAL PRIMARY KEY,
    Nome VARCHAR(100) NOT NULL,
    Estilo VARCHAR(100) NOT NULL,
    Preco DECIMAL(10, 2) NOT NULL,
    Desconto DECIMAL(5, 2)
);

-- Tabela de Usuários
CREATE TABLE Usuario (
    Usuario_id SERIAL PRIMARY KEY,
    NomeUsuario VARCHAR(100) NOT NULL,
    Idade INT NOT NULL,
    DataNascimento DATE NOT NULL,
    Email VARCHAR(100) NOT NULL,
    Senha VARCHAR(100) NOT NULL,
    NivelAtual INT NOT NULL,
    QuantidadeXP INT NOT NULL,
    Genero CHAR(1),
    QuadroHorario INT,
    EstiloCustomizacao INT,
    CONSTRAINT fk_nivel_usuario FOREIGN KEY (NivelAtual) REFERENCES Nivel(Nivel_id),
    CONSTRAINT fk_estilo_usuario FOREIGN KEY (EstiloCustomizacao) REFERENCES EstiloCustomizacao(Estilos_id)
);

-- Tabela de Quadros de Horários 
CREATE TABLE QuadroHorario (
    NumeroQuadro SERIAL PRIMARY KEY,
    Usuario_id INT NOT NULL,
    Horarios VARCHAR(50) NOT NULL,
    CONSTRAINT fk_usuario FOREIGN KEY (Usuario_id) REFERENCES Usuario(Usuario_id)
);

CREATE TABLE QuadroTarefa (
    Quadro_id INT,
    Tarefa_id INT,
    PRIMARY KEY (Quadro_id, Tarefa_id),
    CONSTRAINT fk_quadro FOREIGN KEY (Quadro_id) REFERENCES QuadroHorario(NumeroQuadro),
    CONSTRAINT fk_tarefa FOREIGN KEY (Tarefa_id) REFERENCES Tarefa(Tarefa_id)
);

