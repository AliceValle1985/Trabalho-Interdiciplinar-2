function showScreen(screenId) {
    // Ocultar todas as telas
    const screens = document.querySelectorAll('.screen');
    screens.forEach(screen => {
        screen.classList.remove('active');
        screen.classList.add('hidden');
    });

    // Mostrar a tela solicitada
    const screen = document.getElementById(screenId);
    screen.classList.remove('hidden');
    screen.classList.add('active');
}

function goToTaskPanel() {
    showScreen('task-panel-screen');
}

function openProfileModal() {
    // Abrir o modal de perfil
    document.getElementById('profile-modal').style.display = 'block';
}

function closeProfileModal() {
    // Fechar o modal de perfil
    document.getElementById('profile-modal').style.display = 'none';
}

// fechar 
function closeProfileSection() {
    document.getElementById('edit-profile-section').classList.add('hidden');
}

function closeThemeSection() {
    document.getElementById('edit-theme-section').classList.add('hidden');
}

function toggleEditSection(section) {
    // Ocultar ambas as seções
    document.getElementById('edit-profile-section').classList.add('hidden');
    document.getElementById('edit-theme-section').classList.add('hidden');

    // Mostrar a seção correta com base na escolha do usuário
    if (section === 'profile') {
        document.getElementById('edit-profile-section').classList.remove('hidden');
    } else if (section === 'theme') {
        document.getElementById('edit-theme-section').classList.remove('hidden');
    }
    document.getElementById('profile-modal').style.display = 'none';
}

function changeTheme(theme) {
    document.documentElement.className = theme;
}

// calcula o nivel do xp para o proximo nível 
function level() {
}

function saveProfile(shouldSave) {
    if (!shouldSave) {
        alert("As mudanças não foram salvas.");
        return;
    }

    // Coleta os dados do formulário
    var nome = document.getElementById("new-profile-name").value;
    var email = document.getElementById("new-profile-email").value;
    var senha = document.getElementById("new-profile-senha").value;
    var imagem = document.getElementById("new-profile-image").files[0];

    // Validação simples dos campos
    if (!nome || !email || !senha) {
        alert("Por favor, preencha todos os campos.");
        return;
    }

    // Preparar o objeto de dados do perfil
    var formData = new FormData();
    formData.append("nome", nome);
    formData.append("email", email);
    formData.append("senha", senha);

    if (imagem) {
        formData.append("imagem", imagem); // Se houver imagem selecionada
    }

    // Enviar os dados ao servidor via requisição POST
    fetch('http://localhost:4567/editarPerfil', {
        method: 'POST',
        body: formData // Enviar os dados usando FormData, que inclui arquivos
    })
        .then(response => response.json()) // Parse da resposta JSON
        .then(data => {
            if (data.sucesso) {
                alert('Perfil atualizado com sucesso!');
                // Aqui, você pode redirecionar ou atualizar a página
                loadProfileData();
            } else {
                alert('Erro ao atualizar o perfil: ' + data.mensagem);
            }
        })
        .catch(error => {
            console.error('Erro ao atualizar o perfil:', error);
            alert('Erro ao atualizar o perfil.');
        });
}

function loadProfileData() {
    // Fazer uma requisição GET ao servidor para obter os dados do perfil
    fetch('http://localhost:4567/perfil')
        .then(response => response.json()) // Converte a resposta para JSON
        .then(data => {
            // Atualiza os elementos HTML com os dados do perfil
            document.getElementById('profile-name').innerText = data.nome;
            document.getElementById('profile-level').innerText = 'Nível ' + data.nivel;
        })
        .catch(error => {
            console.error('Erro ao carregar os dados do perfil:', error);
        });
}

//window.onload = loadProfileData;

// Iniciar o site com o Tema 1
changeTheme('theme1');

function calcularTempoRestante() {
    // Obtém os valores dos inputs de horário
    const horarioInicio = document.getElementById('horarioInicio').value;
    const horarioFim = document.getElementById('horarioFim').value;

    // Converte os horários para o formato de Date, usando uma data arbitrária
    const [horaInicio, minutoInicio] = horarioInicio.split(':').map(Number);
    const [horaFim, minutoFim] = horarioFim.split(':').map(Number);

    const dataInicio = new Date(0, 0, 0, horaInicio, minutoInicio, 0);
    const dataFim = new Date(0, 0, 0, horaFim, minutoFim, 0);

    // Calcula a diferença em milissegundos
    let diffMs = dataFim - dataInicio;

    // Se o horário de fim for menor que o de início, significa que o horário de fim é no próximo dia
    if (diffMs < 0) {
        diffMs += 24 * 60 * 60 * 1000; // Adiciona 24 horas em milissegundos
    }

    // Converte a diferença para horas e minutos
    let diffHoras = Math.floor(diffMs / (1000 * 60 * 60));
    let diffMinutos = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

    // Exibe o resultado na página
    document.getElementById('resultado').innerText = `Duração da Task: ${diffHoras} horas e ${diffMinutos} minutos.`;

    if (diffMinutos === 0) {
        diffMinutos += '0';
    }
    return (diffHoras.toString().length === 1) ? '0' + diffHoras + ':' + diffMinutos : diffHoras + ':' + diffMinutos;
}



/**
 * @author MateusEvangelista 
 * 
 */
function enviarTask() {
    // Coleta os dados do formulário
    const taskData = {
        nome: document.getElementById('taskName').value,
        cor: defineColor(document.getElementById('priority-content').textContent),
        duracao: calcularTempoRestante(),
        horarioInicio: document.getElementById('horarioInicio').value,
        horarioFim: document.getElementById('horarioFim').value,
        descricao: document.getElementById('Descricao').value,
    };

    // Envia os dados via fetch para o servidor Spark
    fetch('http://localhost:60000/tasks', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(taskData)
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro na rede: ' + response.statusText);
            }
            return response.json();
        })

        .then(data => {
            console.log('Task enviada com sucesso:');
        })

        .catch((error) => {
            // Exibe mensagem de erro
            console.error('Erro:', error);
            alert("Erro ao enviar a task: " + error.message);
        });

        window.location.href = '../public/TabelaHorarios.html';
    console.log(taskData);
}

/**
 * @author MateusEvangelista 
 * 

function setPriority(priority) {
    if (priority === 'verylow') return 'blue';
    if (priority === 'low') return 'green';
    if (priority === 'medium') return 'yellow';
    if (priority === 'hight') return 'red';
}
 */


/**
 * @author MateusEvangelista 
 * 
 */
function setPriority(priority) {
    if (priority === 'verylow') document.getElementById("priority-content").innerHTML = 'Muito baixa';
    if (priority === 'low') document.getElementById("priority-content").innerHTML = 'Baixa'
    if (priority === 'medium') document.getElementById("priority-content").innerHTML = 'Média';
    if (priority === 'hight') document.getElementById("priority-content").innerHTML = 'Alta';
}

/**
 * @author MateusEvangelista 
 * 
 */
function defineColor(priority) {
    
    if (priority === 'Muito baixa') return 'blue'; 
    if (priority === 'Baixa') return 'green';
    if (priority === 'Média') return 'yellow'; 
    if (priority === 'Alta') return 'red'; 
    return 'TESTE'
}