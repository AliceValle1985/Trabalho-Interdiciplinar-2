document.getElementById("btn_registrar_conta").addEventListener("click", Registrador);
document.getElementById("btn_entrar_em_conta").addEventListener("click", IniciarSessao);
window.addEventListener("resize", ConcertaPagina);
// variaeis
var caixa_login_registrar = document.querySelector( ".login-registrador" );
var formulario_login = document.querySelector( ".formulario-login" );
var formulario_registrar = document.querySelector( ".formulario-registrar" );
var caixa_atras_login = document.querySelector( ".atras_login" );
var caixa_atras_registrar = document.querySelector( ".caixa_atras_registrar" );

function ConcertaPagina()
{
    if( window.innerWidth > 850 )
    {
        caixa_atras_login.style.display = "block";
        caixa_atras_registrar.style.display = "block";
    }
    else
    {
        caixa_atras_registrar.style.display = "block";
        caixa_atras_registrar.style.opacity = "1";
        caixa_atras_login.style.display = "none";
        formulario_login.style.display = "block";
        formulario_registrar.style.display = "none";
        caixa_login_registrar.style.left = "0px";
    }
}
ConcertaPagina();
function IniciarSessao(){
    if( window.innerWidth > 850 )
    {
        formulario_registrar.style.display = "none";
        caixa_login_registrar.style.left = "10px";
        formulario_login.style.display = "block";
        caixa_atras_registrar.style.opacity = "1";
        caixa_atras_login.style.opacity = "0";
    }
    else
    {
        formulario_registrar.style.display = "none";
        caixa_login_registrar.style.left = "0px";
        formulario_login.style.display = "block";
        caixa_atras_registrar.style.display = "block";
        caixa_atras_login.style.display = "none";
    }
    
}
// botão registrar-se ( faz a animação )
function Registrador(){
    if( window.innerWidth > 850 )
    {
        formulario_registrar.style.display = "block";
        caixa_login_registrar.style.left = "400px";
        formulario_login.style.display = "none";
        caixa_atras_registrar.style.opacity = "0";
        caixa_atras_login.style.opacity = "1";
    }
    else
    {
        formulario_registrar.style.display = "block";
        caixa_login_registrar.style.left = "0px";
        formulario_login.style.display = "none";
        caixa_atras_registrar.style.display = "none";
        caixa_atras_login.style.display = "block";
        caixa_atras_login.style.opacity = "1";
    }
    
    document.addEventListener("DOMContentLoaded", function() {
        const form = document.querySelector('.formulario-registrar');
        form.addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent the default form submission
            
            const formData = new FormData(form);
            fetch('/usuario/insert', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Erro na inserção do usuário');
                }
                return response.json();
            })
            .then(data => {
                alert(data); // Show the success or error message in an alert
                form.reset(); // Optionally reset the form
            })
            .catch(error => {
                alert('Erro: ' + error.message);
            });
        });
    });

}