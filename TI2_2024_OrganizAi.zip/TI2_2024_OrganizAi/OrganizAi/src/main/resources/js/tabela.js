



document.addEventListener('click', function (event) {
    if (event.target.classList.contains('task-complete-button')) {
        const tarefaId = event.target.dataset.id;
        console.log("Task ID:", tarefaId);

        fetch('http://localhost:8080/tarefa/concluirTarefa', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: tarefaId })
        })
        .then(response => response.json())
        .then(data => {
            console.log(data);
            this.location.reload();
        })   
        .catch(error => console.error('Error:', error));
    }
});



document.addEventListener("DOMContentLoaded", function() {
    // Fetch data from the backend on port 8080
	fetch('http://localhost:8080/task/get/all')
	    .then(response => {
	        if (!response.ok) {
	            throw new Error("Error fetching tasks: " + response.statusText);
	        }
	        return response.text(); // Ensure you are handling text correctly
	    })
	    .then(data => {
	        console.log('Fetched data:', data);
	        const scheduleBody = document.getElementById("scheduleBody");
	        scheduleBody.innerHTML = data; 
	    })
	    .catch(error => {
	        console.error('Error:', error);
	        document.getElementById("scheduleBody").innerHTML = "<tr><td colspan='2'>Failed to load tasks.</td></tr>";
	    });


// Função para ex
function displayTarefas(tarefas) {
    const scheduleBody = document.getElementById("scheduleBody");

    // Limpa o corpo da tabela antes de adicionar novas tarefas
    scheduleBody.innerHTML = "";

    // Preenche a tabela com as tarefas
    tarefas.forEach((tarefa) => {
        const row = document.createElement("tr");

        // Célula de horário
        const timeCell = document.createElement("td");
        timeCell.textContent = `${tarefa.horarioInicio} - ${tarefa.horarioFim}`;

        // Célula de atividade
        const activityCell = document.createElement("td");
        activityCell.textContent = tarefa.nome;

        // Criando o botão "Ver", inicialmente oculto
        const viewButton = document.createElement("button");
        viewButton.textContent = "Ver";
        viewButton.style.display = "none"; // Ocultar inicialmente
        viewButton.style.marginLeft = "10px"; // Adiciona um espaço entre o botão e o texto

        // Evento para mostrar o pop-up quando o botão "Ver" for clicado
        viewButton.onclick = function () {
            showPopup(tarefas[hour]);
        };

        // Adicionar evento para mostrar o botão quando o mouse passar por cima
        row.addEventListener("mouseover", function () {
            viewButton.style.display = "inline"; // Mostrar o botão
        });

        // Adicionar evento para esconder o botão quando o mouse sair
        row.addEventListener("mouseout", function () {
            viewButton.style.display = "none"; // Esconder o botão
        });

        // Adicionando o botão "Ver" na célula de atividade
        activityCell.appendChild(viewButton);

        // Adicionando as células na linha
        row.appendChild(timeCell);
        row.appendChild(activityCell);

        // Adicionando a linha na tabela
        scheduleBody.appendChild(row);

        // Aplicando a cor de fundo às células
        timeCell.style.backgroundColor = getActivityColor(tarefa.cor);
        activityCell.style.backgroundColor = getActivityColor(tarefa.cor);

        // Evento para mostrar o pop-up quando o botão "Ver" for clicado
        viewButton.onclick = function () {
            showPopup(tarefa);
        };

        // Adicionando o botão na célula de atividade
        activityCell.appendChild(viewButton);

        // Adicionando as células na linha
        row.appendChild(timeCell);
        row.appendChild(activityCell);

        // Adicionando a linha na tabela
        scheduleBody.appendChild(row);
    });
}

// Função para fechar o pop-up
function closePopup() {
    document.getElementById("popup").style.display = "none";
}

// Função para fechar o pop-up
function closeNewPopup() {
    document.getElementById("newPopup").style.display = "none";
}

// Função para mostrar o pop-up com os dados da tarefa
function showPopup(tarefa) {
    const popup = document.getElementById("popup");

    // Preenchendo os dados da tarefa no pop-up
    document.getElementById("popupTarefaNome").textContent = `Nome: ${tarefa.nome}`;
    document.getElementById("popupTarefaDescricao").textContent = `Descrição: ${tarefa.descricao}`;
    document.getElementById("popupTarefaInicio").textContent = `Início: ${tarefa.horarioInicio}`;
    document.getElementById("popupTarefaFim").textContent = `Fim: ${tarefa.horarioFim}`;

    // Mostra o pop-up
    popup.style.display = "block";

    // Definindo ações para os botões "Alterar" e "Deletar"
    document.getElementById("alterarButton").onclick = function () {
        showUpdatePopup(tarefa); // Chama a função para mostrar o pop-up de atualização
    };

    document.getElementById("deletarButton").onclick = function () {
        if (confirm(`Você realmente deseja deletar a tarefa: ${tarefa.nome}?`)) {
            // Envia a requisição DELETE
            fetch(`http://localhost:60000/tasks/${tarefa.id}`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                }
            })
                .then(response => {
                    if (response.ok) {
                        alert("Tarefa deletada com sucesso!");
                        closePopup(); // Fecha o pop-up
                        atualizarListaTarefas()
                    } else {
                        alert("Erro ao deletar a tarefa.");
                    }
                });
        }
    };
}

// Função para mostrar o pop-up de atualização
function showUpdatePopup(tarefa) {
    const newPopup = document.getElementById("newPopup");

    // Preenchendo os dados da tarefa no pop-up de atualização
    document.getElementById("newTaskName").value = tarefa.nome;
    document.getElementById("priority-content").value = tarefa.cor;
    document.getElementById("newDescricao").value = tarefa.descricao;
    document.getElementById("newHorarioInicio").value = tarefa.horarioInicio;
    document.getElementById("newHorarioFim").value = tarefa.horarioFim;

    // Mostra o pop-up de atualização
    newPopup.style.display = "flex";

    // Fecha o pop-up de atualização ao clicar no botão de fechar
    document.getElementById("closePopup").onclick = function () {
        newPopup.style.display = "none";
    };

    // Lidar com o envio do formulário de atualização
    document.getElementById("newTaskForm").onsubmit = function (event) {
        event.preventDefault(); // Impede o envio padrão do formulário

        // Obtém os novos valores dos inputs ou usa os valores antigos se não forem alterados
        const updatedTask = {
            nome: document.getElementById("newTaskName").value || tarefa.nome,
            cor:  defineColor(document.getElementById("priority-content").innerText) || tarefa.cor,
            duracao : tarefa.duracao,
            descricao: document.getElementById("newDescricao").value || tarefa.descricao,
            horarioInicio: document.getElementById("newHorarioInicio").value || tarefa.horarioInicio,
            horarioFim: document.getElementById("newHorarioFim").value || tarefa.horarioFim
        };

        // Envia os dados (novos ou antigos) para o servidor
        fetch(`http://localhost:60000/tasks/${tarefa.id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(updatedTask)
        })
            .then(response => {
                if (response.ok) {
                    alert("Tarefa atualizada com sucesso!");
                    newPopup.style.display = "none"; // Fecha o pop-up de atualização
                    closePopup(); // Fecha o pop-up principal
                    atualizarListaTarefas();
                } else {
                    alert("Erro ao atualizar a tarefa.");
                }
            });
    };
}


// Função para atualizar a lista de tarefas no frontend
function atualizarListaTarefas() {
    fetchTarefas(); // Refaz a busca das tarefas para atualizar a lista
}

// Função para exibir o formulário de atualização (não implementado no HTML atual)
function showUpdateForm(tarefa) {
    // Aqui você pode implementar o código para exibir outro pop-up ou modal com o formulário de atualização da tarefa
    alert(`Exibindo o formulário para atualizar a tarefa: ${tarefa.nome}`);
}


function setPriority(priority) {
    if (priority === 'verylow') document.getElementById("priority-content").innerHTML = 'Muito baixa';
    if (priority === 'low') document.getElementById("priority-content").innerHTML = 'Baixa'
    if (priority === 'medium') document.getElementById("priority-content").innerHTML = 'Média';
    if (priority === 'hight') document.getElementById("priority-content").innerHTML = 'Alta';
}

/**
 * @author MateusEvangelista 
 * 
 */
function defineColor(priority) {
    if (priority === 'Muito baixa') return 'blue'; 
    if (priority === 'Baixa') return 'green';
    if (priority === 'Média') return 'yellow'; 
    if (priority === 'Alta') return 'red'; 
}

// Função para definir a cor da atividade com base na hora
function getActivityColor(color) {
    if (color === "yellow") return "#FFD700";
    if (color === "blue") return "#ADD8E6";
    if (color === "green") return "#90EE90";
    if (color === "red") return "#FFB6C1";
    return "#FFFFFF"; // Default (white)
}
})