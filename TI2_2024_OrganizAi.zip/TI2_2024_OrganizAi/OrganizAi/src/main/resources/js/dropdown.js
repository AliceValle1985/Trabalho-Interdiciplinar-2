function showScreen(screenId) {
    // Ocultar todas as telas
    const screens = document.querySelectorAll('.screen');
    screens.forEach(screen => {
        screen.classList.remove('active');
        screen.classList.add('hidden');
    });

    // Mostrar a tela solicitada
    const screen = document.getElementById(screenId);
    screen.classList.remove('hidden');
    screen.classList.add('active');
}

function goToTaskPanel() {
    showScreen('task-panel-screen');
}

function openProfileModal() {
    // Abrir o modal de perfil
    document.getElementById('profile-modal').style.display = 'block';
}

function closeProfileModal() {
    // Fechar o modal de perfil
    document.getElementById('profile-modal').style.display = 'none';
}

// fechar 
function closeProfileSection() {
    document.getElementById('edit-profile-section').classList.add('hidden');
}

function closeThemeSection() {
    document.getElementById('edit-theme-section').classList.add('hidden');
}

function toggleEditSection(section) {
    // Ocultar ambas as seções
    document.getElementById('edit-profile-section').classList.add('hidden');
    document.getElementById('edit-theme-section').classList.add('hidden');

    // Mostrar a seção correta com base na escolha do usuário
    if (section === 'profile') {
        document.getElementById('edit-profile-section').classList.remove('hidden');
    } else if (section === 'theme') {
        document.getElementById('edit-theme-section').classList.remove('hidden');
    }
    document.getElementById('profile-modal').style.display = 'none';
}

function changeTheme(theme) {
    document.documentElement.className = theme;
}

// calcula o nivel do xp para o proximo nível 
function level() {

}

function saveProfile(saveChanges) {
    if (saveChanges) {
        // Alterar nome, e-mail e senha
        const newName = document.getElementById('new-profile-name').value;
        const newEmail = document.getElementById('new-profile-email').value;
        const newSenha = document.getElementById('new-profile-senha').value;

        // Atualiza o nome, email e senha no perfil
        if (newName) {
            document.getElementById('new-profile-name').textContent = newName;
        }
        if (newEmail) {
            document.getElementById('new-profile-email').textContent = newEmail;
        }
        if (newSenha) {
            document.getElementById('new-profile-senha').textContent = newSenha;
        }

         // Alterar imagem
         const newImageInput = document.getElementById('new-profile-image');
         if (newImageInput.files && newImageInput.files[0]) {
             const newImageURL = URL.createObjectURL(newImageInput.files[0]);
             document.getElementById('profile-image').src = newImageURL;
             document.getElementById('profile-icon-img').src = newImageURL; // Atualiza também o ícone no canto superior
         }
 
        alert("Alterações salvas com sucesso!");
    }

    // Fechar a modal após salvar ou cancelar
    closeProfileSection();
}


// Iniciar o site com o Tema 1
changeTheme('theme1');

