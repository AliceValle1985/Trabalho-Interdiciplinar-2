document.addEventListener("DOMContentLoaded", function() {
  document.getElementById('sendButton').addEventListener('click', async () => {
    console.log('Botão Enviar clicado'); // Confirma se o evento está sendo disparado
    const imageInput = document.getElementById('imageInput');
    const file = imageInput.files[0];

    if (!file) {
      alert('Por favor, selecione uma imagem.');
      return;
    }

    const subscriptionKey = "7bcaad752d2c451795b65642d28a9620";
    const endpoint = "https://1453563.cognitiveservices.azure.com";

    try {
      const response = await fetch(`${endpoint}/vision/v3.2/read/analyze`, {
        method: 'POST',
        headers: {
          'Ocp-Apim-Subscription-Key': subscriptionKey,
          'Content-Type': 'application/octet-stream',
        },
        body: file,
      });

      if (!response.ok) {
        throw new Error('Erro na solicitação: ' + response.statusText);
      }

      const operationLocation = response.headers.get('Operation-Location');
      if (!operationLocation) {
        throw new Error('Não foi possível obter o local da operação.');
      }

      let ocrResult;
      do {
        const resultResponse = await fetch(operationLocation, {
          headers: { 'Ocp-Apim-Subscription-Key': subscriptionKey }
        });
        ocrResult = await resultResponse.json();
        await new Promise(resolve => setTimeout(resolve, 1000));
      } while (ocrResult.status !== "succeeded");

      let extractedText = "";
      ocrResult.analyzeResult.readResults.forEach(page => {
        page.lines.forEach(line => {
          extractedText += line.text + "\n";
        });
      });

      const resultContainer = document.getElementById('resultContainer');
      resultContainer.innerHTML = `
        <textarea id="extractedText" rows="5" style="width: 100%;">${extractedText.trim()}</textarea>
        <button id="copyButton" class="btn btn-secondary" style="margin-top: 10px;">Copiar Tudo</button>
      `;

      document.getElementById('copyButton').addEventListener('click', () => {
        const textArea = document.getElementById('extractedText');
        navigator.clipboard.writeText(textArea.value).then(() => {
          alert('Texto copiado!');
        }).catch(err => {
          console.error('Erro ao copiar o texto:', err);
        });
      });

    } catch (error) {
      console.error('Erro ao enviar a imagem:', error);
      alert('Ocorreu um erro ao processar a imagem. Verifique o console para mais detalhes.');
    }
  });
});


