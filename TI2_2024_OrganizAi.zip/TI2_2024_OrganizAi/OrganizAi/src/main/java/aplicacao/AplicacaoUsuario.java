package aplicacao;

import static spark.Spark.*;

//import java.util.List;

//import com.google.gson.Gson;

//import model.Tarefa;
import service.NivelService;
import service.TarefaService;
import service.UsuarioService;
import service.QuadroService;

public class AplicacaoUsuario {

	private static TarefaService tarefaService = new TarefaService();
	private static NivelService nivelService = new NivelService();
	private static UsuarioService usuarioService = new UsuarioService();
	private static QuadroService quadroService = new QuadroService();
	
	public static void main(String[] args)
	{
		port(8080);
		
		staticFiles.location("/public");
		
		options("/*", (request, response) -> {
		    String accessControlRequestHeaders = request.headers("Access-Control-Request-Headers");
		    if (accessControlRequestHeaders != null) {
		        response.header("Access-Control-Allow-Headers", accessControlRequestHeaders);
		    }

		    String accessControlRequestMethod = request.headers("Access-Control-Request-Method");
		    if (accessControlRequestMethod != null) {
		        response.header("Access-Control-Allow-Methods", accessControlRequestMethod);
		    }

		    return "OK";
		});
		
		before((request, response) -> {
		    response.header("Access-Control-Allow-Origin", "*"); 
		    response.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
		    response.header("Access-Control-Allow-Headers", "Content-Type");
		});
		
		
		
		//USUARIO
		post("/usuario/insert", (request, response) -> usuarioService.insert(request, response)); //TESTADO
		
		get("/usuario/get", (request, response) -> usuarioService.get(request, response)); //TESTADO
		
		post("/usuario/update", (request, response) -> usuarioService.getToUpdate(request, response)); //TESTADO
		
		get("/usuario/delete/:id", (request, response) -> usuarioService.delete(request, response)); //TESTADO
		
		get("/usuario/listar",(request, response) -> usuarioService.listarTodosUsuarios(request, response)); //TESTADO
		
		
		
		//TASKS
		post("/task/insert", (request, response) -> tarefaService.adicionarTarefa(request, response)); //TESTADO.
		
		get("/task/get", (request, response) -> tarefaService.getTarefa(request, response)); //TESTADO
		
		post("/task/update", (request, response) -> tarefaService.updateTarefa(request, response)); //TESTADO
		
		get("/task/delete", (request, response) -> tarefaService.removerTarefa(request, response)); //TESTADO
		
		get("task/get/all", (request, response) -> tarefaService.getTarefas(request, response)); //TESTADO
		
		
		//NIVEL
		post("/nivel/insert", (request, response) -> nivelService.insert(request, response)); //TESTADO
		
        get("/Nivel/nivel", (request, response) -> nivelService.get(request, response)); //CRIAR
        
        get("/Nivel/update/nivel", (request, response) -> nivelService.update(request, response)); //CRIAR
        
        get("/Nivel/delete/nivel", (request, response) -> nivelService.delete(request, response)); //CRIAR
        
        get("/Nivel", (request, response) -> nivelService.getAll(request, response)); //CRIAR
        
        
        //RESTANTE
        post("/quadro/insert", (request, response) -> quadroService.insert(request, response)); //TESTADO
        
        get("/quadro/getByUser", (resquest, response) -> quadroService.getByUsuario(resquest, response));
        
        post("/tarefa/concluirTarefa", (request, response) -> tarefaService.concluirTarefa(request, response)); //TESTADO
        
        //TIRAR LOCAL NO FRONT-END
	}
	
}
	
