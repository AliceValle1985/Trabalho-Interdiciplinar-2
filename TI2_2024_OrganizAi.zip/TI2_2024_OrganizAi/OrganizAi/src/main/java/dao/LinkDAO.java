package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
//import java.sql.Statement;

import model.Nivel;
import model.Quadro;
import model.QuadroTarefa;
import model.Tarefa;
import model.Usuario;

public class LinkDAO {

	public String getIdList(QuadroTarefa[] lista)
    {
    	String s = "(";
    	int i = 0;
    	for(i = 0; i<lista.length-1; i++)
    	{
    		s += lista[i].getTID() + ", ";
    	}
    	s += lista[i].getTID() + ")";
    	return s;
    }

    public Tarefa[] getTarefasUsuario()
    {
    	UsuarioDAO dao = new UsuarioDAO();
    	QuadroDAO daoQ = new QuadroDAO();
    	
    	Quadro[] lista = daoQ.getAllById(1);
    	QuadroTarefa[] lista2 = null;
    	Tarefa[] listatarefas = null;
    	
    	
    	//int resp = 0;
    	
    	int id_quadro = lista[0].getId();
    	try
    	{
    		String sql = "SELECT * FROM quadrotarefa WHERE quadro_id = ?";
            PreparedStatement st = dao.conexao.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
    		st.setInt(1, id_quadro);
            ResultSet rs = st.executeQuery ();
            if(rs.next())
            {
                rs.last();
                lista2 = new QuadroTarefa[rs.getRow()];
                rs.beforeFirst();

                for (int i = 0; rs.next(); i++)
                {
                    lista2[i] = new QuadroTarefa(rs.getInt("quadro_id"), rs.getInt("tarefa_id"));
                }
            }
            st.close();
        }
    	catch (Exception e)
        {
             System.err.println(e.getMessage());   
        }
    	try
    	{	
    		String sql = "SELECT * FROM tarefa WHERE tarefa_id IN ?";
            PreparedStatement st = dao.conexao.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
    		st.setString(1, getIdList(lista2));
            ResultSet rs = st.executeQuery ();
            
            if(rs.next())
            {
                rs.last();
                listatarefas = new Tarefa[lista2.length];
                rs.beforeFirst();

                for (int i = 0; rs.next(); i++)
                {
                    listatarefas[i] = new Tarefa(Integer.parseInt(rs.getString("tarefa_id")) , rs.getString("nome"),rs.getString("horarioinicio"), rs.getString("horariofim"), rs.getString("descricao"));
                }
            }
            st.close();
    	}
    	catch (Exception e)
        {
             System.err.println(e.getMessage());   
        }
    	//CONTINUAR DAQUI
    	// procurar no quadrotarefa por tarefas com
    	
    	
    	return listatarefas;
    }
    
    public boolean concluirTarefa(int id_tarefa)
    {
    	UsuarioDAO daoU = new UsuarioDAO();
    	TarefaDAO daoT = new TarefaDAO();
    	QuadroDAO daoQ = new QuadroDAO();
    	NivelDAO daoN = new NivelDAO();
    	
    	daoU.conectar();
    	daoT.conectar();
    	daoQ.conectar();
    	daoN.conectar();
    	
    	boolean resp = false;
    	
    	QuadroTarefa qt = null;
    	Quadro q = null;
    	Tarefa concluida = null;
    	Usuario u = null;
    	Nivel atual = null;
    	
    	try
    	{
    		concluida = daoT.getTarefa(id_tarefa);
    	}
    	catch (Exception e)
        {
             System.err.println(e.getMessage());   
        }
    	
    	int pts = concluida.getPontosConclusao();
    	
    	
    	
    	//get quadrotarefa atraves de id_tarefa concluido
    	try
    	{
    		String sql = "SELECT * FROM quadrotarefa WHERE tarefa_id = ?";
            PreparedStatement st = daoQ.conexao.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
    		st.setInt(1, id_tarefa);
            ResultSet rs = st.executeQuery();
    		
            if(rs.next())
            {
                rs.last();
                qt = new QuadroTarefa(rs.getInt("quadro_id"), rs.getInt("tarefa_id"));
                rs.beforeFirst();
            }
            st.close();
        }
    	catch (Exception e)
        {
             System.err.println(e.getMessage());   
        }
    	
    	//get quadro a partir do id_quadro obtido em quadrotarefa
    	try
    	{
    		String sql = "SELECT * FROM quadrohorario WHERE numeroquadro = ?";
            PreparedStatement st = daoQ.conexao.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
    		st.setInt(1, qt.getQID());
            ResultSet rs = st.executeQuery();
            if(rs.next())
            {
                rs.last();
                q = new Quadro(rs.getString("horarios"), rs.getInt("usuario_id"), qt.getQID());
                rs.beforeFirst();
            }
            st.close();
        }
    	catch (Exception e)
        {
             System.err.println(e.getMessage());   
        }
    	
    	try
    	{
	    	//get usuario a partir de usuario_id em quadrohorarios
	    	u = daoU.getUsuario(q.getUsuario());
	    	
	    	//get regra prox nivel
	    	
	    	
	    	int totalEXP = u.getXp() + pts;
	    	atual = daoN.getNivel(u.getLevel());
	    	int result = totalEXP;
	    	while (result >= atual.getRegra())
	    	{
		    	result = result - atual.getRegra();
		    	System.out.println(totalEXP);
		    	System.out.println(result);
		    	
		    	int w = u.getLevel() + 1;
			    u.setLevel(w);
			    atual = daoN.getNivel(w);
			}
	    	u.setXp(result);
	    	daoU.updateUsuario(u);
	    	daoT.delete(id_tarefa);
	    	resp = true;
    	}
    	catch (Exception e)
        {
             System.err.println(e.getMessage());   
        }
    	
    	return resp;
    }
    
    public static void main(String[] args)
    {
    }
}
