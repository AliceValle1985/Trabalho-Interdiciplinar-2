package dao;

import java.sql.*;
import model.Nivel;

public class NivelDAO extends DAO {

    public NivelDAO() {
        super();
    }

    public boolean insertNivel(Nivel n) {
        boolean status = false;
        String sql = "INSERT INTO nivel (nivel_id, regra, recompensa) VALUES (?, ?, ?)";
        
        NivelDAO dao = new NivelDAO();
    	dao.conectar();
        
            try 
            { 
            	PreparedStatement st = dao.conexao.prepareStatement(sql);
                st.setInt(1, n.getNivel());
                st.setInt(2, n.getRegra());
                st.setString(3, n.getRecompensa());
                st.executeUpdate();
                status = true;
            } 
            catch (SQLException e) 
            {
                System.err.println("Erro ao inserir nivel: " + e.getMessage());
            } 
            finally 
            {
                dao.close();
            }
        return status;
    }

    public boolean updateNivel(Nivel n) {
        boolean status = false;
        String sql = "UPDATE nivel SET regra = ?, recompensa = ? WHERE nivel_id = ?";

        	NivelDAO dao = new NivelDAO();
        	dao.conectar();
        
            try
            {
            	PreparedStatement st = dao.conexao.prepareStatement(sql);
                st.setInt(1, n.getRegra());
                st.setString(2, n.getRecompensa());
                st.setInt(3, n.getNivel());
                st.executeUpdate();
                status = true;
            } 
            catch (SQLException e) 
            {
                System.err.println("Erro ao atualizar nivel: " + e.getMessage());
            } 
            finally 
            {
                dao.close();
            }
        return status;
    }

    public boolean removeNivel(int nivel) {
        boolean status = false;
        String sql = "DELETE FROM nivel WHERE nivel_id = ?";

        NivelDAO dao = new NivelDAO();
    	dao.conectar();
        
            try
            {
            	PreparedStatement st = dao.conexao.prepareStatement(sql);
                st.setInt(1, nivel);
                st.executeUpdate();
                status = true;
            } catch (SQLException e) {
                System.err.println("Erro ao remover nivel: " + e.getMessage());
            } finally {
                dao.close();
            }
        return status;
    }

    public Nivel getNivel(int nivel) {
        Nivel n = null;
        String sql = "SELECT * FROM nivel WHERE nivel_id = ?";
        NivelDAO dao = new NivelDAO();
    	dao.conectar();
        
            try
            {
            	PreparedStatement st = dao.conexao.prepareStatement(sql);
                st.setInt(1, nivel);
                try (ResultSet rs = st.executeQuery()) 
                {
                    if (rs.next()) 
                    {
                        int regra = rs.getInt("regra");
                        String recompensa = rs.getString("recompensa");
                        n = new Nivel(nivel, regra, recompensa);
                    }
                }
            } 
            catch (SQLException e) 
            {
                System.err.println("Erro ao obter nivel: " + e.getMessage());
            } 
            finally 
            {
                dao.close();
            }
        return n;
    }

    public Nivel[] listarNiveis() {
        Nivel[] niveis = null;
        String sql = "SELECT * FROM nivel";
        NivelDAO dao = new NivelDAO();
    	dao.conectar();
       
            try (
            		PreparedStatement st = dao.conexao.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            		ResultSet rs = st.executeQuery()) 
            {

                if (rs.next()) {
                    rs.last();
                    niveis = new Nivel[rs.getRow()];
                    rs.beforeFirst();
                    int i = 0;
                    while (rs.next()) {
                        int nivel = rs.getInt("nivel");
                        int regra = rs.getInt("regra");
                        String recompensa = rs.getString("recompensa");
                        niveis[i++] = new Nivel(nivel, regra, recompensa);
                    }
                }
            } 
            catch (SQLException e) 
            {
                System.err.println("Erro ao listar niveis: " + e.getMessage());
            } 
            finally 
            {
                dao.close();
            }
        return niveis;
    }
    
    public static void main (String[] args)
    {
    	NivelDAO dao = new NivelDAO();
    	Nivel n = dao.getNivel(1);
    	System.out.println(n.getNivel());
    }
}