package dao;

import java.sql.*;

import model.Quadro;

public class QuadroDAO extends DAO
{

	public QuadroDAO()
	{
		super();
	}
    
    /*
     *  Trocar para preparedStatement posteriormente
     *  Implementar criptografia
     */
	
    public boolean insertQuadro(Quadro quadro)
    {
    	QuadroDAO dao = new QuadroDAO();
    	dao.conectar();
    	
        boolean status = false;
        try
        {
        	String sql = "INSERT INTO quadrohorario (usuario_id, horarios) VALUES (?, ?)";
        	PreparedStatement st = dao.conexao.prepareStatement(sql);
        	st.setInt(1, quadro.getUsuario());
            st.setString(2, quadro.getQuebra());
            st.executeUpdate();
            st.close();
            status = true;
        }
        catch (SQLException u)
        {
            throw new RuntimeException(u);
        }
        return status;
    }


    

    public boolean updateQuadro(Quadro quadro)
    {
    	
        boolean status = false;
        QuadroDAO dao = new QuadroDAO();
    	dao.conectar();
        try
        {
        	String sql = "UPDATE quadrohorario SET usuario_id = ?, horarios = ? WHERE numeroquadro = ?";
        	PreparedStatement st = dao.conexao.prepareStatement(sql);
        	st.setInt(1, quadro.getUsuario());
        	st.setString(2, quadro.getQuebra());
        	st.setInt(3, quadro.getId());
            st.executeUpdate();
            st.close();
            status = true;
        }
        catch (SQLException u)
        {
            throw new RuntimeException (u);
        }
        dao.close();
        return status;
    }


    
    public boolean removeQuadro (int id)
    {
        boolean status = false;
        QuadroDAO dao = new QuadroDAO();
    	dao.conectar();
        try
        {
        	String sql = "DELETE FROM quadrohorario WHERE Quadro_id = ?";
        	PreparedStatement st = dao.conexao.prepareStatement(sql);
        	st.setInt(1, id);
            st.executeUpdate();
            st.close();
            status = true;
        }
        catch (SQLException u)
        {
            throw new RuntimeException(u);
        }
        dao.close();
        return status;
    }



    public Quadro getQuadro(int id)
    {
        Quadro Quadro = null;
        
        QuadroDAO dao = new QuadroDAO();
    	dao.conectar();
        
        try
        {
        	String sql = "SELECT * FROM quadrohorario WHERE numeroquadro = ?";
        	PreparedStatement st = dao.conexao.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        	st.setInt(1, id);
        	ResultSet rs = st.executeQuery();
            if(rs.next())
            {
                rs.last();
                Quadro = new Quadro(rs.getString("horarios"), Integer.parseInt(rs.getString("usuario_id")),Integer.parseInt(rs.getString("numeroquadro")));
                rs.beforeFirst();
            }
        }
        catch (Exception e)
        {
             System.err.println(e.getMessage());   
        }
        dao.close();
        return Quadro;
    }
    
    
    public Quadro[] listarQuadros()
    {
        Quadro[] Quadros = null;
        QuadroDAO dao = new QuadroDAO();
    	dao.conectar();
        try
        {
        	String sql = "SELECT * FROM quadrohorario";
        	PreparedStatement st = dao.conexao.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        	ResultSet rs = st.executeQuery();
            if(rs.next())
            {
                rs.last();
                Quadros = new Quadro[rs.getRow()];
                rs.beforeFirst();

                for (int i = 0; rs.next(); i++)
                {
                    Quadros[i] = new Quadro(rs.getString("horarios"), Integer.parseInt(rs.getString("usuario_id")),Integer.parseInt(rs.getString("numeroquadro")));
                    System.out.println(Quadros[i].toString());	
                }
            }
            st.close();
        }
        catch (Exception e)
        {
             System.err.println(e.getMessage());   
        }
        dao.close();
        return Quadros;
    }

    
    public Quadro[] getAllById(int id_usuario)
    {
    	Quadro[] Quadros = null;
        QuadroDAO dao = new QuadroDAO();
     	dao.conectar();
         try
         {
        	String sql = "SELECT * FROM quadrohorario WHERE usuario_id = ?";
         	PreparedStatement st = dao.conexao.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
         	st.setInt(1, id_usuario);
         	ResultSet rs = st.executeQuery();
             if(rs.next())
             {
                 rs.last();
                 Quadros = new Quadro[rs.getRow()];
                 rs.beforeFirst();

                 for (int i = 0; rs.next(); i++)
                 {
                     Quadros[i] = new Quadro(rs.getString("horarios"), Integer.parseInt(rs.getString("usuario_id")),Integer.parseInt(rs.getString("numeroquadro")));
                     System.out.println(Quadros[i].toString());
                 }
             }
             st.close();
         }
         catch (Exception e)
         {
              System.err.println(e.getMessage());   
         }
         dao.close();
         return Quadros;
    }
    

    
     
	    
}
