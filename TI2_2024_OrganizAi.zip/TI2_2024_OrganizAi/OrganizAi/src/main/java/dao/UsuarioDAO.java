package dao;

import java.sql.*;
//import java.text.SimpleDateFormat;
import java.time.LocalDate;

import model.Usuario;



public class UsuarioDAO extends DAO
{

	public UsuarioDAO()
	{
		super();
	}
    
    /*
     *  Trocar para preparedStatement posteriormente
     *  Implementar criptografia
     */
	
    public boolean insertUsuario(Usuario usuario)
    {
    	Date date = Date.valueOf(usuario.getDdn());
    	//SimpleDateFormat form	 = new SimpleDateFormat("dd-MM-yyyy");
    	
    	UsuarioDAO dao = new UsuarioDAO();
    	dao.conectar();
    	
    	
    	
        boolean status = false;
        try
        {
        	
        	
        	
        	String sql = "INSERT INTO usuario (nomeusuario,datanascimento,senha,email,idade,nivelatual,quantidadexp,genero) " + 
                	"VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        	PreparedStatement st = dao.conexao.prepareStatement(sql);
        	
        	st.setString(1, usuario.getNome());
            st.setDate(2, date);
            st.setString(3, DAO.toMD5(usuario.getSenha()));
            st.setString(4, usuario.getEmail());
            st.setInt(5, usuario.calcIdade());
            st.setInt(6, usuario.getLevel());
            st.setInt(7, usuario.getXp());
            st.setString(8, String.valueOf(usuario.getGenero()));  
            st.executeUpdate();
            st.close();
            status = true;
        }
        catch (SQLException u)
        {
            throw new RuntimeException(u);
        }
        return status;
    }


    

    public boolean updateUsuario(Usuario usuario)
    {
    	Date date = Date.valueOf(usuario.getDdn());
        boolean status = false;
        UsuarioDAO dao = new UsuarioDAO();
    	dao.conectar();
        try
        {
        	String sql = "UPDATE usuario SET nomeusuario = ?, datanascimento = ?, genero = ?, quantidadexp = ?, nivelatual = ?, senha = ?, email = ? WHERE usuario_id = ?";
        	PreparedStatement st = dao.conexao.prepareStatement(sql);
        	
        	st.setString(1, usuario.getNome());
        	st.setDate(2, date);
        	st.setString(3, String.valueOf(usuario.getGenero()));
        	st.setInt(4, usuario.getXp());
        	st.setInt(5, usuario.getLevel());
            st.setString(6, DAO.toMD5(usuario.getSenha()));
            st.setString(7, usuario.getEmail());
            st.setInt(8, usuario.getId());
            
            st.executeUpdate();
            st.close();
            status = true;
        }
        catch (SQLException u)
        {
            throw new RuntimeException (u);
        }
        dao.close();
        return status;
    }


    
    public boolean removeUsuario (int id)
    {
        boolean status = false;
        UsuarioDAO dao = new UsuarioDAO();
    	dao.conectar();
        try
        {
        	String sql = "DELETE FROM usuario WHERE usuario_id = ?";
        	PreparedStatement st = dao.conexao.prepareStatement(sql);
        	st.setInt(1, id);
            st.executeUpdate();
            st.close();
            status = true;
        }
        catch (SQLException u)
        {
            throw new RuntimeException(u);
        }
        dao.close();
        return status;
    }



    public Usuario getUsuario(int id)
    {
        Usuario usuario = null;
        
        UsuarioDAO dao = new UsuarioDAO();
    	dao.conectar();
        
        try
        {
        	String sql = "SELECT * FROM usuario WHERE usuario_id = ?";
        	PreparedStatement st = dao.conexao.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        	st.setInt(1, id);
            ResultSet rs = st.executeQuery();
            if(rs.next())
            {
                rs.last();
                usuario = new Usuario(rs.getString("genero").charAt(0), rs.getString("nomeusuario"), LocalDate.parse(rs.getString("datanascimento")), rs.getInt("idade"), rs.getInt("quantidadexp"), rs.getInt("nivelatual"), rs.getString("senha"), rs.getString("email"), id);
                rs.beforeFirst();
            }
        }
        catch (Exception e)
        {
             System.err.println(e.getMessage());   
        }
        dao.close();
        return usuario;
    }
    
    
    public Usuario[] listarUsuarios()
    {
        Usuario[] usuarios = null;
        UsuarioDAO dao = new UsuarioDAO();
    	dao.conectar();
        try
        {
        	String sql = "SELECT * FROM usuario";
        	PreparedStatement st = dao.conexao.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = st.executeQuery();
            if(rs.next())
            {
                rs.last();
                usuarios = new Usuario[rs.getRow()];
                rs.beforeFirst();

                for (int i = 0; rs.next(); i++)
                {
                    usuarios[i] = new Usuario(rs.getString("genero").charAt(0), rs.getString("nomeusuario"), rs.getString("datanascimento"), rs.getInt("idade"), rs.getString("senha"), rs.getString("email"), Integer.parseInt(rs.getString("usuario_id")));
                }
            }
            st.close();
        }
        catch (Exception e)
        {
             System.err.println(e.getMessage());   
        }
        dao.close();
        return usuarios;
    }
    
    
    
    public static void main (String[] args)
    {
    	UsuarioDAO dao = new UsuarioDAO();
    	dao.conectar();
    	
    	Usuario us = dao.getUsuario(1);
    	System.out.println(us.toString());
    	
    	us.setXp(0);
    	System.out.println(us.toString());
    	
    	dao.updateUsuario(us);
    	
    	
    	dao.close();
    	
    }


    
    
}