package dao;

import java.sql.*;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import model.Tarefa;


public class TarefaDAO extends DAO {

    public TarefaDAO() {
        super();
        conectar();
    }

    public void finalize() {
        close();
    }




    public boolean insert(Tarefa tarefa, int quadro) 
    {
    	TarefaDAO dao = new TarefaDAO();
        boolean status = false;
        try {
            String sql = "INSERT INTO tarefa (nome, cor, duracao, horarioinicio, horariofim, pontosconclusao, descricao) "
                       + "VALUES (?, ?, ?, ?, ?, ?, ?) RETURNING tarefa_id";

            PreparedStatement st = conexao.prepareStatement(sql);
            st.setString(1, tarefa.getNome());
            st.setString(2, tarefa.getCor());

            	
            LocalTime localTimeInicio = LocalTime.parse(tarefa.getHorarioInicio());
            LocalTime localTimeFim = LocalTime.parse(tarefa.getHorarioFim());
            LocalTime localTimeDuracao = LocalTime.parse(Tarefa.calcDuracao(localTimeInicio,localTimeFim));
            
            // Converter duracao de String para LocalTime e depois para SQL Time
            Time sqlTimeDuracao = Time.valueOf(localTimeDuracao);
            st.setTime(3, sqlTimeDuracao);
            
            // Converter horarioInicio de String para LocalTime e depois para SQL Time
            Time sqlTimeInicio = Time.valueOf(localTimeInicio);
            st.setTime(4, sqlTimeInicio);

            // Converter horarioFim de String para LocalTime e depois para SQL Time
            Time sqlTimeFim = Time.valueOf(localTimeFim);
            st.setTime(5, sqlTimeFim);

            st.setInt(6, tarefa.calcPontos(localTimeDuracao));
            st.setString(7, tarefa.getDescricao());

            ResultSet rs = st.executeQuery();
            if (rs.next()) 
            {
                int tarefaId = rs.getInt("tarefa_id");
	            if (dao.link(tarefaId, quadro))
	            {
	            	System.out.println("Link bem sucedido");
	            }
            }
            st.close();
            status = true;
            
            //fazer conexão com tabela horariotarefa função separada!
        } 
        catch (SQLException u) 
        {
            throw new RuntimeException(u);
        }
        return status;
    }
    
    public boolean link(int tarefa, int quadro)
    {
    	boolean status = false;
    	try 
    	{
    		String sql= "INSERT INTO quadrotarefa (quadro_id, tarefa_id) " + "VALUES (?, ?)";
    		PreparedStatement st = this.conexao.prepareStatement(sql);
            st.setInt(1, quadro);
            st.setInt(2, tarefa);
            st.executeUpdate();
            st.close();
    	}
    	catch (Exception u) 
        {
            throw new RuntimeException(u);
        }
    	return status;
    }
    
    public Tarefa getTarefa(int id)
    {
        Tarefa tarefa = null;
        
        try
        {
        	String sql = "SELECT * FROM tarefa WHERE tarefa_id = ?";
            PreparedStatement st = conexao.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            st.setInt(1, id);
            ResultSet rs = st.executeQuery();
            if(rs.next())
            {
                rs.last();
                tarefa = new Tarefa(Integer.parseInt(rs.getString("tarefa_id")) , rs.getString("nome"), rs.getString("cor"), rs.getString("duracao"), rs.getString("horarioinicio"), rs.getString("horariofim"), rs.getString("descricao"), Integer.parseInt(rs.getString("pontosconclusao")));
                rs.beforeFirst();
            }
        }
        catch (Exception e)
        {
             System.err.println(e.getMessage());   
        }
        return tarefa;
    }
    
    public List<Tarefa> get() {
        return get("");
    }

    public List<Tarefa> getOrderById() {
        return get("id");
    }

    public List<Tarefa> getOrderByNome() {
        return get("nome");
    }

    public List<Tarefa> getOrderByCor() {
        return get("cor");
    }
    
    public List<Tarefa> getOrderByHorarioInicio() {
        return get("horarioinicio");
    }

    public List<Tarefa> getOrderByDuracao() {
        return get("duracao");
    }

    private List<Tarefa> get(String orderBy) 
    {
    	
        List<Tarefa> tarefas = new ArrayList<Tarefa>();
        try {
            Statement st = conexao.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String sql = "SELECT * FROM tarefa";
            System.out.println(sql);
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                Tarefa tarefa = new Tarefa(
                    rs.getInt("tarefa_id"),
                    rs.getString("nome"),
                    rs.getString("horarioinicio"),
                    rs.getString("horariofim"),
                    rs.getString("descricao")
                );
                tarefa.setCor(rs.getString("cor"));
                tarefa.setDuracao(rs.getString("duracao"));
                tarefa.setPontosConclusao(rs.getInt("pontosConclusao"));
                //System.out.println(tarefa.toString());
                tarefas.add(tarefa);
            }
            st.close();
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
        return tarefas;
    }

    public boolean update(Tarefa tarefa) {
        boolean status = false;
        try {
            String sql = "UPDATE tarefa SET nome = ?, cor = ?, duracao = ?, horarioinicio = ?, horariofim = ?, pontosconclusao = ?, descricao = ? WHERE tarefa_id = ?";
            
            PreparedStatement st = conexao.prepareStatement(sql);
            
            LocalTime localTimeInicio = LocalTime.parse(tarefa.getHorarioInicio());
            LocalTime localTimeFim = LocalTime.parse(tarefa.getHorarioFim());
            LocalTime localTimeDuracao = LocalTime.parse(Tarefa.calcDuracao(localTimeInicio,localTimeFim));
            
            st.setString(1, tarefa.getNome());
            st.setString(2, tarefa.getCor());

            // Converter duracao de String para LocalTime e depois para SQL Time
            
            Time sqlTimeDuracao = Time.valueOf(localTimeDuracao);
            st.setTime(3, sqlTimeDuracao);

            // Converter horarioInicio de String para LocalTime e depois para SQL Time
            
            Time sqlTimeInicio = Time.valueOf(localTimeInicio);
            st.setTime(4, sqlTimeInicio);

            // Converter horarioFim de String para LocalTime e depois para SQL Time
            
            Time sqlTimeFim = Time.valueOf(localTimeFim);
            st.setTime(5, sqlTimeFim);

            st.setInt(6, tarefa.calcPontos(localTimeDuracao));
            st.setString(7, tarefa.getDescricao());
            st.setInt(8, tarefa.getId()); // Id da tarefa

            st.executeUpdate();
            st.close();
            status = true;
        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
        return status;
    }


    public boolean delete(int id) {
        boolean status = false;
        try {
        	String sql1 = "DELETE FROM quadrotarefa WHERE tarefa_id = ?";
            String sql2 = "DELETE FROM tarefa WHERE tarefa_id = ?";
            PreparedStatement st = conexao.prepareStatement(sql1, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            st.setInt(1, id);
            st.executeUpdate();
            
            st = conexao.prepareStatement(sql2, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            st.setInt(1, id);
            st.executeUpdate();
            
            st.close();
            status = true;
        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
        return status;
    }

    /*
    public boolean autenticar(String nome, String cor) {
        boolean resp = false;
        try {
            Statement st = conexao.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String sql = "SELECT * FROM tarefa WHERE nome LIKE '" + nome + "' AND cor LIKE '" + cor + "'";
            System.out.println(sql);
            ResultSet rs = st.executeQuery(sql);
            resp = rs.next();
            st.close();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return resp;
    }
    */
}
