package service;

import spark.Request;
import spark.Response;
//import java.util.Scanner;
import java.time.LocalDate;
//import java.io.File;
//import java.time.LocalDateTime;
//import java.util.List;
//import com.google.gson.Gson;


import dao.UsuarioDAO;
//import model.Tarefa;
import model.Usuario;

public class UsuarioService 
{
	private UsuarioDAO usuarioDAO = new UsuarioDAO();

	//private String form;

	
	
	
	public Object insert (Request request, Response response)
	{

		String nome = request.queryParams("nome");
		String email = request.queryParams("email");
		String senha = request.queryParams("senha");
		String g = request.queryParams("genero");
		char genero = g.charAt(0);
		String ddn = request.queryParams("ddn");
		
		String[] data = ddn.split("-");
    	LocalDate date = LocalDate.of(Integer.parseInt(data[0]),Integer.parseInt(data[1]),Integer.parseInt(data[2]));
		
		
		
		String resp = "";
		
		//idade vai ser calculada na dao
		Usuario usuario = new Usuario(genero, nome, date, Usuario.calcIdade(date), senha, email);
		
		  if (usuarioDAO.insertUsuario(usuario)) 
		  {
		        response.status(201);
		        resp = "<script>alert('Usuario (" + nome + ") inserido com sucesso!'); window.location.href='http://127.0.0.1:5500/src/main/resources/public/registro.html'; </script>";
		  } 
		  else 
		  {
		        resp = "<script>alert('Erro ao inserir usuario (" + nome + ")!'); window.location.href='http://127.0.0.1:5500/src/main/resources/public/registro.html'; </script>"; //window.location.href='/form-page';
		  }

		    response.type("text/html");
		    return resp;
	}
	
	public Object get(Request request, Response response)
	{
		int id = Integer.parseInt(request.queryParams("id"));
		Usuario usuario = (Usuario) usuarioDAO.getUsuario(id);
		
		String resp = "";
		
		if (usuario != null)
		{
			response.status(200);
			resp = usuario.toString();
		}
		else
		{
			response.status(404);
			resp = "Usuario (" + id + ") nao encontrado.";
			//makeform
		}
		return resp;
	}
	
	public Object getToUpdate(Request request, Response response)
	{
		int id = Integer.parseInt(request.queryParams("id_update"));
		String nome = request.queryParams("edit-name");
		String email = request.queryParams("edit-email");
		String senha = request.queryParams("edit-senha");
		char genero = '\0';
		if(request.queryParams("genero") != null) genero = request.queryParams("genero").charAt(0);
		
		Usuario usuario = (Usuario)usuarioDAO.getUsuario(id);
		
		String resp = "";
		
		if (usuario != null)
		{
			if(nome!=null && nome!="") usuario.setNome(nome);
			if(email!=null && email!="")usuario.setEmail(email);
			if(senha!=null && senha!="")usuario.setSenha(senha);
			if(genero!=' ' && genero != '\0')usuario.setGenero(genero);
			usuarioDAO.updateUsuario(usuario);
			response.status(200);
			resp = "Usuario (" + id + ") atualizado.";
		}
		else
		{
			response.status(404);
			resp = "Usuario (" + id + ") nao encontrado.";
			//makeform
		}
		return resp;
	}
	
	
	public Object delete (Request request, Response response)
	{
		int id = Integer.parseInt(request.queryParams("del-id"));
		
		Usuario usuario = (Usuario) usuarioDAO.getUsuario(id);
		String resp = "";
		
		if (usuario != null)
		{
			usuarioDAO.removeUsuario(id);
			response.status(200);
			resp = "Usuario (" + id + ") foi removido.";
		}
		else
		{
			response.status(404);
			resp = "Usuario (" + id + ") nao encontrado.";
		}

		return resp;
	}
	
	public Object listarTodosUsuarios(Request request, Response response) 
	{
        Usuario[] lista = usuarioDAO.listarUsuarios();
        
        String resp = "";
        if (lista != null)
        {
        	response.status(200);
        	for (int i = 0; i<lista.length; i++)
        	{
        		resp += lista[i].toString() + "\n";
        	}
        }
        return resp;
    }
}
