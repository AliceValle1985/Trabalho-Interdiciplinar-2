package service;

import dao.QuadroDAO;
import model.Quadro;
import spark.Request;
import spark.Response;

public class QuadroService {

	private QuadroDAO quadroDAO = new QuadroDAO();

	
	
	
	public Object insert (Request request, Response response)
	{

		String quebra = request.queryParams("quebra");
		
		String resp = "";
		
		//idade vai ser calculada na dao
		Quadro quadro = new Quadro(quebra, 1);
		
		if(quadroDAO.insertQuadro(quadro) == true)
		{
			resp = "Quadro inserido!";
			response.status(201);
		}
		else
		{
			resp = "Quadro nao inserido!";
		}
		return resp;
	}
	
	public Object get(Request request, Response response)
	{
		int id = Integer.parseInt(request.queryParams("id"));
		Quadro Quadro = (Quadro) quadroDAO.getQuadro(id);
		
		String resp = "";
		
		if (Quadro != null)
		{
			response.status(200);
			resp = Quadro.toString();
		}
		else
		{
			response.status(404);
			resp = "Quadro (" + id + ") nao encontrado.";
			//makeform
		}
		return resp;
	}
	
	public Object getByUsuario(Request request, Response response)
	{
		int id = 1;//Integer.parseInt(request.queryParams("id"));
		Quadro Quadro = (Quadro) quadroDAO.getQuadro(id);
		
		String resp = "";
		
		if (Quadro != null)
		{
			response.status(200);
			resp = Quadro.toString();
		}
		else
		{
			response.status(404);
			resp = "Quadro (" + id + ") nao encontrado.";
			//makeform
		}
		return resp;
	}
	
	public Object getToUpdate(Request request, Response response)
	{
		int id = Integer.parseInt(request.queryParams("id"));
		String quebra = request.queryParams("quebra");
		
		Quadro Quadro = quadroDAO.getQuadro(id);
		
		String resp = "";
		
		if (Quadro != null)
		{
			Quadro.setId(id);
			Quadro.setQuebra(quebra);
			quadroDAO.updateQuadro(Quadro);
			response.status(200);
			resp = "Quadro (" + id + ") atualizado.";
		}
		else
		{
			response.status(404);
			resp = "Quadro (" + id + ") nao encontrado.";
			//makeform
		}
		return resp;
	}
	
	
	public Object delete (Request request, Response response)
	{
		int id = Integer.parseInt(request.queryParams("del-id"));
		
		Quadro Quadro = quadroDAO.getQuadro(id);
		String resp = "";
		
		if (Quadro != null)
		{
			quadroDAO.removeQuadro(id);
			response.status(200);
			resp = "Quadro (" + id + ") foi removido.";
		}
		else
		{
			response.status(404);
			resp = "Quadro (" + id + ") nao encontrado.";
		}

		return resp;
	}
	
	public Object listarTodosQuadros(Request request, Response response) 
	{
        Quadro[] lista = quadroDAO.listarQuadros();
        
        String resp = "";
        if (lista != null)
        {
        	response.status(200);
        	for (int i = 0; i<lista.length; i++)
        	{
        		resp += lista[i].toString() + "\n";
        	}
        }
        return resp;
    }
}
