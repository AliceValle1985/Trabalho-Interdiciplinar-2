package service;

import java.util.List;
import dao.TarefaDAO;
import dao.LinkDAO;
import model.Tarefa;
import spark.Request;
import spark.Response;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class TarefaService {

    private TarefaDAO tarefaDAO;

    public TarefaService() {
        tarefaDAO = new TarefaDAO();
    }

    public String adicionarTarefa(Request request, Response response) 
    {
    	String nome = request.queryParams("taskName");
		String cor = request.queryParams("cor");
		String horarioInicio = request.queryParams("horarioInicio");
		String horarioFim = request.queryParams("horarioFim");
		String descricao = request.queryParams("Descricao");
		
		
		String resp = "";
		
		//String nome, String cor, String duracao, String horarioInicio, String horarioFim, String descricao
		Tarefa tarefa = new Tarefa(nome, cor, "", horarioInicio, horarioFim, descricao);
		
		if(tarefaDAO.insert(tarefa, 1) == true)
		{
			//http://127.0.0.1:5500/src/main/resources/public/TabelaHorarios.html
			resp = "<script>alert('Tarefa (" + nome + ") inserida com sucesso!'); window.location.href='http://127.0.0.1:5500/src/main/resources/public/TabelaHorarios.html'; </script>";
			response.status(201);
		}
		else
		{
			resp = "<script>alert('Tarefa (" + nome + ") NAO inserida!'); window.location.href='http://127.0.0.1:5500/src/main/resources/public/TabelaHorarios.html'; </script>";
		}
		response.type("text/html");
		return resp;
    }
    
    public String getTarefas(Request request, Response response)
    {
    	response.type("text/html");
    	List<Tarefa> tarefas = tarefaDAO.getOrderByCor();
    		
        
    	StringBuilder htmlResponse = new StringBuilder();
		String resp = "";
		
		if (tarefas != null)
		{
			response.status(200);
			for (Tarefa tarefa : tarefas) {
				
	            htmlResponse.append("<tr>")
	            			.append("<td><button class='task-complete-button' data-id='").append(tarefa.getId()).append("'>Completar</button></td>")
	                        .append("<td>").append(tarefa.getHorarioInicio()).append(" - ").append(tarefa.getHorarioFim()).append("</td>")
	                        .append("<td  style='background-color: ").append(tarefa.getPriority(tarefa.getCor())) // Assuming tarefa.getCor() returns a valid color
	    	                .append(";'>").append(tarefa.getNome()).append(" - ").append(tarefa.getDescricao()).append("</td>")
	                        .append("</tr>");
	        }
			 
			 resp = htmlResponse.toString();  // Return the full HTML structure
		}
		else
		{
			response.status(404);
			htmlResponse.append("<p> \"Lista de tarefas vazia.\"</p>");
			resp = htmlResponse.toString();
			//makeform
		}
		System.out.println(resp);
		return resp;
    }
   /* 
    public Tarefa buscarTarefaPorId(int id) {
        if (id > 0) {
            return tarefaDAO.get(id);
        }
        return null;
    }
    */
    public List<Tarefa> listarTodasTarefas() {
        return tarefaDAO.get();
    }

    public List<Tarefa> listarTarefasOrdenadasPor(String criterio) {
        switch (criterio.toLowerCase()) {
            case "id":
                return tarefaDAO.getOrderById();
            case "nome":
                return tarefaDAO.getOrderByNome();
            case "cor":
                return tarefaDAO.getOrderByCor();
            case "duracao":
                return tarefaDAO.getOrderByDuracao();
            case "horarioinicio":
                return tarefaDAO.getOrderByHorarioInicio();
            default:
                return tarefaDAO.get(); // Retorna sem ordenação se o critério for inválido
        }
    }

    public Object updateTarefa(Request request, Response response) 
    {
    	String resp = "";
    	
    	int id = Integer.parseInt(request.queryParams("id_update"));
		Tarefa tarefa = (Tarefa) tarefaDAO.getTarefa(id);
    	String nome = request.queryParams("taskName");
		String cor = request.queryParams("cor");
		String horarioInicio = request.queryParams("horarioInicio");
		String horarioFim = request.queryParams("horarioFim");
		String descricao = request.queryParams("Descricao");
		
		
		//System.out.println(nome);
		if (nome != null && nome != "") tarefa.setNome(nome);
		if (cor != null && cor != "") tarefa.setCor(cor);
		if (horarioInicio != null && horarioInicio != "") tarefa.setHorarioInicio(horarioInicio);
		if (horarioFim != null && horarioFim != "") tarefa.setHorarioFim(horarioFim);
		if (descricao != null && descricao != "") tarefa.setDescricao(descricao);
		
		if(tarefaDAO.update(tarefa) == true)
		{
			resp = "Tarefa (" + nome + ") atualizada!";
			System.out.println(tarefa.toString());
			response.status(201);
		}
		else
		{
			resp = "Tarefa (" + nome + ") nao atualizada!";
		}
		return resp;
    }
	
    public String removerTarefa(Request request, Response response) 
	{
		int id = Integer.parseInt(request.queryParams("del-id"));
		
		Tarefa tarefa = (Tarefa) tarefaDAO.getTarefa(id);
		String resp = "";
		
		if (tarefa != null)
		{
			tarefaDAO.delete(id);
			response.status(200);
			resp = "Tarefa (" + id + ") foi removido.";
		}
		else
		{
			response.status(404);
			resp = "Tarefa (" + id + ") nao encontrado.";
		}

		return resp;
	}
    
    public Object getTarefa(Request request, Response response)
    {
    	int id = Integer.parseInt(request.queryParams("id"));
		Tarefa tarefa = (Tarefa) tarefaDAO.getTarefa(id);
		
		String resp = "";
		
		if (tarefa != null)
		{
			response.status(200);
			resp = tarefa.toString();
		}
		else
		{
			response.status(404);
			resp = "Tarefa (" + tarefa + ") nao encontrado.";
			//makeform
		}
		return resp;
    }
    
    public Object concluirTarefa(Request request, Response response)
    {
    	LinkDAO dao = new LinkDAO();
    	
    	JsonObject requestBody = JsonParser.parseString(request.body()).getAsJsonObject();
        int id_tarefa = requestBody.get("id").getAsInt();
    	
    	String resp = "";
        
    	if (dao.concluirTarefa(id_tarefa) == true)
		{
			response.status(200);
			resp = "<script>window.location.reload()'; </script>";
		}
		else
		{
			response.status(404);
			resp = "<script> alert('Erro'); window.location.reload()'; </script>";
			response.type("text/html");
		}
    	
    	return resp;
    }
    
    /*
    public boolean autenticarTarefa(String nome, String cor) {
        if (nome != null && cor != null && !nome.isEmpty() && !cor.isEmpty()) {
            return tarefaDAO.autenticar(nome, cor);
        }
        return false;
    }
    */

}
