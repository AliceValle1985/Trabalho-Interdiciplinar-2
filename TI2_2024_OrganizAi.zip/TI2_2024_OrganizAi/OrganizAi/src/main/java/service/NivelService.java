package service;
	

import dao.NivelDAO;

import model.Nivel;
import spark.Request;
import spark.Response;

public class NivelService {

    public NivelDAO nivelDAO = new NivelDAO();

    /*
    public NivelService ( ) 
    {
        nivelDAO = new NivelDAO ( );
        nivelDAO.conectar ( );
    }
    */

    public Object insert(Request request, Response response) {
        String nivel_str = request.queryParams("nivel");
        String regra_str = request.queryParams("regra");
        String recompensa = request.queryParams("recompensa");
        	
        int nivel = Integer.parseInt(nivel_str);
        int regra = Integer.parseInt(regra_str);

        Nivel n = new Nivel(nivel, regra, recompensa);
        System.out.println(n.toString());
        nivelDAO.insertNivel(n);
        response.status(201);
        return n;
    }

    public String get(Request request, Response response) {
        String nivel_str = request.queryParams("nivel");
        int nivel = Integer.parseInt(nivel_str);
        Nivel n = (Nivel) nivelDAO.getNivel(nivel);
        if (n != null) {
            return n.toString();
        } else {
            response.status(404);
            return "Nao encontrado";
        }
    }

    public String update(Request request, Response response) {
        String nivel_str = request.queryParams("nivel");
        String regra_str = request.queryParams("regra");
        int nivel = Integer.parseInt(nivel_str);
        int regra = Integer.parseInt(regra_str);

        Nivel n = (Nivel) nivelDAO.getNivel(nivel);
        if (n != null) {
            n.setNivel(nivel);
            n.setRegra(regra);
            n.setRecompensa(request.queryParams("recompensa"));
            nivelDAO.updateNivel(n);
            return n.toString();
        } else {
            response.status(404);
            return "Nao encontrado";
        }
    }

    public int delete(Request request, Response response) {
        String nivel_str = request.queryParams("nivel");
        int nivel = Integer.parseInt(nivel_str);
        Nivel n = (Nivel) nivelDAO.getNivel(nivel);
        if (n != null) {
            nivelDAO.removeNivel(nivel);
            response.status(200);
            return nivel;
        } else {
            response.status(404);
            System.err.println("Nao encontrado");
            return -1;
        }
    }

    public String getAll(Request request, Response response) {
        Nivel[] n = nivelDAO.listarNiveis();
        String ret = "";
        {
            for (int i = 0; i < n.length; i++) {
                ret = ret + "\n" + n[i].toString();
            }
        }
        return ret;
    }
}