package model;

import java.time.LocalTime;

public class Tarefa {
	private int id;
	private String nome;
	private String cor;
	private String duracao;
	private String horarioInicio;
	private String horarioFim;
	private int pontosConclusao;
	private String descricao;
	
	
	public Tarefa(int id, String nome, String horarioInicio, String horarioFim, String descricao) {
		this.id = id;
		this.nome = nome;
		this.horarioInicio = horarioInicio;
		this.horarioFim = horarioFim;
		this.descricao = descricao;
	}
	
	public Tarefa(String nome, String cor, String duracao, String horarioInicio, String horarioFim, String descricao) {
		this.nome = nome;
		this.cor = cor;
		this.duracao = duracao;
		this.horarioInicio = horarioInicio;
		this.horarioFim = horarioFim;
		this.descricao = descricao;
	}

	public Tarefa(String nome, String cor, String duracao, String horarioInicio, String horarioFim, String descricao, int pontosConclusao) {
		this.nome = nome;
		this.cor = cor;
		this.duracao = duracao;
		this.horarioInicio = horarioInicio;
		this.horarioFim = horarioFim;
		this.descricao = descricao;
		this.pontosConclusao = pontosConclusao;
	}
	
	public Tarefa(int id, String nome, String cor, String duracao, String horarioInicio, String horarioFim, String descricao, int pontosConclusao) {
		this.id = id;
		this.nome = nome;
		this.cor = cor;
		this.duracao = duracao;
		this.horarioInicio = horarioInicio;
		this.horarioFim = horarioFim;
		this.descricao = descricao;
		this.pontosConclusao = pontosConclusao;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getCor() {
		return cor;
	}


	public void setCor(String cor) {
		this.cor = cor;
	}


	public String getDuracao() {
		return duracao;
	}
	
	public static String calcDuracao(LocalTime inicio, LocalTime fim)
	{
		String d;
		int prehora = (fim.getHour() - inicio.getHour())*60;
		int premins = fim.getMinute() - inicio.getMinute();
		int res = prehora + premins;
		int hora = res/60;
		int mins = (res-(hora*60));
		if(hora<10 && mins<10)
		{
			d = "0" + hora + ":" + "0" + mins;
		}
		else if(hora<10)
		{
			d = "0" + hora + ":" + mins;
		}
		else if(mins<10)
		{
			d = hora + ":" + "0" + mins;
		}
		else 
		{	
			d = hora + ":" + mins;
		}
		return d;
	}


	public void setDuracao(String duracao) {
		this.duracao = duracao;
	}
	
	

	public String getHorarioInicio() {
		return horarioInicio;
	}


	public void setHorarioInicio(String horarioInicio) {
		this.horarioInicio = horarioInicio;
	}


	public String getHorarioFim() {
		return horarioFim;
	}


	public void setHorarioFim(String horarioFim) {
		this.horarioFim = horarioFim;
	}

	public int calcPontos(LocalTime duracao)
	{
		int hora = duracao.getHour();
		int mins = duracao.getMinute();
		
		return ((500*hora) + (8*mins));
	}
	
	public int getPontosConclusao() {
		return pontosConclusao;
	}


	public void setPontosConclusao(int pontosConclusao) {
		this.pontosConclusao = pontosConclusao;
	}

	

	public String getDescricao() {
		return descricao;
	}


	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	public String getPriority(String cor)
	{
		String resp = "";
		if (cor == null)
		{
			resp = "#FFFFFF";
		}
		else if (cor.equals("blue"))
		{
			resp = "#ADD8E6";
		}
		else if (cor.equals("green"))
		{
			resp = "#90EE90";
		}
		else if (cor.equals("yellow"))
		{
			resp = "#FFD700";
		}
		else if (cor.equals("red"))
		{
			resp = "#FFB6C1";
		}
		System.out.println(cor + "-" + resp);
		return resp;
	}
	

	@Override
	public String toString() {
		return "Tarefa [id=" + id + ", nome=" + nome + ", cor=" + cor + ", duracao=" + duracao + ", horarioInicio="
				+ horarioInicio + ", horarioFim=" + horarioFim + ", pontosConclusao=" + pontosConclusao + "]";
	}
	
	
	
	
}
