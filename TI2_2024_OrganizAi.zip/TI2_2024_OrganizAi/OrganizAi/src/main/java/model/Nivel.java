package model;

public class Nivel {
    private int nivel;
    private int regra;
    private String recompensa;

    public Nivel() {
        nivel = 0;
        regra = 0;
        recompensa = "";
    }

    public Nivel(int nivel, int regra, String recompensa) {
        this.nivel = nivel;
        this.regra = regra;
        this.recompensa = recompensa;
    }

    public int getNivel() {
        return nivel;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public int getRegra() {
        return regra;
    }

    public void setRegra(int regra) {
        this.regra = regra;
    }

    public String getRecompensa() {
        return recompensa;
    }

    public void setRecompensa(String recompensa) {
        this.recompensa = recompensa;
    }
}