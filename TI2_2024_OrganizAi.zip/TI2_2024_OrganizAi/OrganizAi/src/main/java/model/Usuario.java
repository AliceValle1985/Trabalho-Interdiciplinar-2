package model;
import java.time.LocalDate;


public class Usuario
{
	private int id;
    private String nome;
	private String email;
    private String senha;
	private char genero;
	private LocalDate ddn;
	private int idade;
    private int xp;
    private int level;
	
	public Usuario()
	{
        this.nome = "";
        this.email = "";
        this.senha = "";
		this.genero = '\0';
        this.ddn = LocalDate.parse("9999-12-31");
        this.idade = -1;
        this.xp = 0;
        this.level = 1;
	}
    
    public Usuario (char genero, String nome, LocalDate ddn, int idade, String senha, String email)
    {
        this.genero = genero;
        this.nome = nome;
        this.ddn = ddn;
        this.idade = calcIdade(ddn);
        this.senha = senha;
        this.email = email;
        this.xp = 0;
        this.level = 1;
    }
    
    public Usuario (char genero, String nome, String ddn, int idade, String senha, String email, int id)
    {
    	//formato da string de data xx-xx-xxxx
    	String[] data = ddn.split("-");
    	LocalDate date = LocalDate.of(Integer.parseInt(data[0]),Integer.parseInt(data[1]),Integer.parseInt(data[2]));
    	
    	this.id = id;
        this.genero = genero;
        this.nome = nome;
        this.ddn = date;
        this.idade = idade;
        this.senha = senha;
        this.email = email;
        this.xp = 0;
        this.level = 1;
    }
    
    public Usuario (char genero, String nome, LocalDate ddn, int idade, int xp, int level, String senha, String email, int id)
    {

    	
    	this.id = id;
        this.genero = genero;
        this.nome = nome;
        this.ddn = ddn;
        this.idade = idade;
        this.senha = senha;
        this.email = email;
        this.xp = xp;
        this.level = level;
    }
    
    public int getId()
    {
    	return this.id;
    }
    
    public char getGenero ()
    {
        return(this.genero);
    }
    public void setGenero (char genero)
    {
        this.genero = genero;
    }

    public String getNome ()
    {
        return(this.nome);
    }
    public void setNome (String nome)
    {
        this.nome = nome;
    }

    public LocalDate getDdn ()
    {
        return (this.ddn);
    }
    public void setDdn(String ddn)
    {
    	String[] data = ddn.split("-");
    	LocalDate date = LocalDate.of(Integer.parseInt(data[2]),Integer.parseInt(data[1]),Integer.parseInt(data[0]));
        this.ddn = date;
    }

    public int getIdade ()
    {
        return (this.idade == -1 ? calcIdade() : this.idade);
    }
    public void setIdade (int idade)
    {
        this.idade = calcIdade();
    }
    public int calcIdade ()
    {
        LocalDate n = LocalDate.now();
        int i = n.getYear() - this.ddn.getYear();
        return i;
    }
    public static int calcIdade (LocalDate ddn)
    {
        LocalDate n = LocalDate.now();
        int i = n.getYear() - ddn.getYear();
        return i;
    }

    public String getEmail ()
    {
        return (this.email);
    }
    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getSenha ()
    {
        return (this.senha);
    }
    public void setSenha(String senha)
    {
        this.senha = senha;
    }

    public int getXp ()
    {
        return (this.xp);
    }
    public void setXp(int xp)
    {
        this.xp = xp;
    }

    public int getLevel()
    {
        return this.level;
    }
    public void setLevel(int level)
    {
        this.level = level;
    }
    
    public String toString ()
    {
        return ("Usuario [nome = " + nome + "; data de nasc. = " + ddn.toString() + "; idade = " + idade + "; email = " + email + "; senha = " + senha + "; genero = " + genero + "; xp atual:" + xp + "; id: " + id + " ]");
    }

    public static void main (String[] args)
    {
        
    }
}
