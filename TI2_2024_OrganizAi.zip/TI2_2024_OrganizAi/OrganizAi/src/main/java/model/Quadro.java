package model;

public class Quadro {

	private int id;
	private String quebra;
	private int usuario_id;
	
	public Quadro()
	{
		this.quebra = "";
		this.usuario_id = 0;
		this.id = 0;
	}
	
	public Quadro(String quebra)
	{
		this.quebra = quebra;
	}
	
	public Quadro(String quebra, int usuario_id)
	{
		this.quebra = quebra;
		this.usuario_id = usuario_id;
	}
	
	public Quadro(int usuario_id)
	{
		this.usuario_id = usuario_id;
	}
	
	public Quadro(String quebra, int usuario_id, int id)
	{
		this.quebra = quebra;
		this.usuario_id = usuario_id;
		this.id = id;
	}
	
	
	public String getQuebra()
	{
		return this.quebra;
	}
	
	public void setQuebra(String Quebra)
	{
		this.quebra = Quebra;
	}
	
	public int getUsuario()
	{
		return this.usuario_id;
	}
	
	public void setUsuario(int usuario_id)
	{
		this.usuario_id = usuario_id;
	}
	
	public int getId()
	{
		return this.id;
	}
	
	public void setId(int id)
	{
		this.id = id;
	}
	
	public String toString ()
    {
        return ("Quadro [id = " + id + "; usuario = " + usuario_id + "; quebra = " + quebra + ";]");
    }
	
}
