package model;

public class QuadroTarefa 
{
	private int quadro_id;
	private int tarefa_id;
	
	public QuadroTarefa()
	{
		quadro_id = 0;
		tarefa_id = 0;
	}
	
	public QuadroTarefa(int idQ)
	{
		quadro_id = idQ;
		tarefa_id = 0;
	}
	
	public QuadroTarefa(int idQ, int idT)
	{
		quadro_id = idQ;
		tarefa_id = idT;
	}
	
	public int getQID()
	{
		return this.quadro_id;
	}
	public void setQID(int id)
	{
		this.quadro_id = id;
	}
	
	public int getTID()
	{
		return this.tarefa_id;
	}
	public void setTID(int id)
	{
		this.tarefa_id = id;
	}
}
